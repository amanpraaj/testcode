# Proximity Sensor Disabler Magisk Module

## Descriptions
- Disables proximity sensor in any Android version

## Requirements
- Magisk or KernelSU installed

## Installation Guide & Download Link
- Install this module https://www.pling.com/p/2100679/ via Magisk app or KernelSU or Recovery if Magisk installed
- Reboot

## Tested on
- Android 10 CrDroid ROM
- Android 11 DotOS ROM
- Android 12 AncientOS ROM
- Android 12.1 Nusantara ROM
- Android 13 Nusantara ROM, AOSP ROM, & CrDroid ROM

## Optionals
- Global: https://t.me/androidryukimodsdiscussions/60861

## Troubleshootings
- Global: https://t.me/androidryukimodsdiscussions/29836

## Support & Bug Report
- https://t.me/androidryukimodsdiscussions/2618
- If you don't do above, issues will be closed immediately

## Credits and contributors
- https://t.me/androidryukimodsdiscussions
- You can contribute ideas about this Magisk Module here: https://t.me/androidappsportdevelopment

## Thanks for Donations
This Magisk Module is always will be free but you can however show us that you are care by making a donations:
- https://ko-fi.com/reiryuki
- https://www.paypal.me/reiryuki
- https://t.me/androidryukimodsdiscussions/2619


