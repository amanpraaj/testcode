if [[ -f /data/adb/modules/RH/reduceheat.sh ]]; then
mv /data/adb/modules/RH/reduceheat.sh /data/adb/service.d
chmod +x /data/adb/service.d/reduceheat.sh
fi